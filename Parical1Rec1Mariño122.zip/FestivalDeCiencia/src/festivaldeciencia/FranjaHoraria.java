package festivaldeciencia;

public enum FranjaHoraria {
    MATUTINA,
    VESPERTINA,
    NOCTURNA;
}
