package festivaldeciencia;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Festival {

    private final String nombre;
    private final List<Actividad> actividades;

    public Festival(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.actividades = new ArrayList<>();
    }

    private void validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo ni estar en blanco.");
        }
    }

    public String getNombre() {
        return nombre;
    }

    /**
     * agrega una actividad al festival.
     *
     *
     * @param actividad actividad a agregar.
     * @throws ActividadDuplicadaException si ya existe otra igual se lanza.
     */
    public void agregarActividad(Actividad actividad) throws ActividadDuplicadaException {
        if (actividad == null) {
            throw new IllegalArgumentException("La actividad no puede ser null.");
        }
        if (actividades.contains(actividad)) {
            throw new ActividadDuplicadaException("Ya existe la actividad " + actividad.getCodigo() + " = " + actividad.getTitulo() + ".");
        }

        actividades.add(actividad);
    }

    /**
     * Devuelve una copita de las acitividades
     *
     * @return lista de actividades
     */
    public List<Actividad> obtenerActividades() {
        return new ArrayList<>(actividades);
    }

    /**
     * devuelve las actividades de una franja horaria.
     *
     * @param franja franja a filtrar.
     * @return actividades de esa franja.
     */
    public List<Actividad> filtrarPorFranja(FranjaHoraria franja) {
        Objects.requireNonNull(franja);

        List<Actividad> resultado = new ArrayList<>();
        for (Actividad a : actividades) {
            if (a.getFranja() == franja) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    /**
     * devuelve las actividades donde la duracion total es menor o igual al
     * limite.
     *
     *
     * @param limite limite de la duracion maxima.
     * @return actividades que cumplen el limite.
     */
    public List<Actividad> obtenerActividadesDeDuracionMaxima(int limite) {
        if (limite <= 0) {
            throw new IllegalArgumentException("El limite debe ser positivo.");
        }

        List<Actividad> resultado = new ArrayList<>();
        for (Actividad a : actividades) {
            if (a.calcularDuracionTotal() <= limite) {
                resultado.add(a);
            }
        }
        return resultado;
    }

}
