package festivaldeciencia;

/**
 * si intenta agregar una actividad duplicada se lanza.
 */
public class ActividadDuplicadaException extends Exception {

    public ActividadDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
