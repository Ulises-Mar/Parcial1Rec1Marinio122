package festivaldeciencia;

/**
 * Muestra interactiva del festival. Permite presentacion pero no reservas.
 */
public class MuestraInteractiva extends Actividad implements Presentable {

    private static final int MINUTOS_POR_ESTACION = 5;
    private final int estaciones;

    public MuestraInteractiva(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int estaciones) {
        super(codigo, titulo, franja, duracionBase);
        validarMayorCero(estaciones);
        this.estaciones = estaciones;

    }

    public int getEstaciones() {
        return estaciones;
    }

    @Override
    public int calcularDuracionTotal() {
        return getDuracionBase() + MINUTOS_POR_ESTACION * estaciones;

    }

    @Override
    public void presentar() {
        System.out.println("Presentacion de charla: " + getTitulo() + ".");

    }

    @Override
    public String toString() {
        return "MuestraInteractiva [codigo= " + getCodigo() + ", titulo= " + getTitulo()
                + ", franja= " + getFranja() + ", duracionBase= " + getDuracionBase()
                + ", estaciones= " + estaciones;
    }
}
