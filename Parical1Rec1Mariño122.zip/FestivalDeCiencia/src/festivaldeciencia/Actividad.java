package festivaldeciencia;

import java.util.Objects;

/**
 * Actividad abstracta del festival. Dos actividades son iguales si tienen el
 * mismo codigo y titulo.
 */
public abstract class Actividad {

    private final String codigo;
    private final String titulo;
    private final FranjaHoraria franja;
    private final int duracionBase;

    public Actividad(String codigo, String titulo, FranjaHoraria franja, int duracionBase) {

        validarTexto(codigo);
        validarTexto(titulo);
        validarMayorCero(duracionBase);
        Objects.requireNonNull(franja, "La franja horaria es obligatoria.");

        this.codigo = codigo;
        this.titulo = titulo;
        this.franja = franja;
        this.duracionBase = duracionBase;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getTitulo() {
        return titulo;
    }

    public FranjaHoraria getFranja() {
        return franja;
    }

    public int getDuracionBase() {
        return duracionBase;
    }

    private void validarTexto(String texto) {
        if (texto == null || texto.isBlank()) {
            throw new IllegalArgumentException("Ingresar un String no vacio.");
        }
    }

    protected void validarMayorCero(int valor) {
        if (valor <= 0) {
            throw new IllegalArgumentException("El valor debe ser mayor a 0.");
        }
    }

    /**
     * calcula la duracion total de la actividad en minutos.
     *
     * @return duracion total en minutos.
     */
    public abstract int calcularDuracionTotal();

    // ------------------------------------------------------------------
    @Override
    public int hashCode() {
        return Objects.hash(codigo, titulo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Actividad)) {
            return false;
        }
        Actividad Otra = (Actividad) obj;
        return codigo.equals(Otra.codigo) && titulo.equals(Otra.titulo);

    }

}
