package festivaldeciencia;

/**
 * Charla del festival. Admite reservas y presentacion.
 */
public class Charla extends Actividad implements Reservable, Presentable {

    private final int minutosPreguntas;
    private int cupos;

    public Charla(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int minutosPreguntas, int cupos) {
        super(codigo, titulo, franja, duracionBase);

        validarMayorCero(cupos);
        validarMayorCero(minutosPreguntas);
        this.minutosPreguntas = minutosPreguntas;
        this.cupos = cupos;

    }

    public int getMinutosPreguntas() {
        return minutosPreguntas;
    }

    @Override
    public int calcularDuracionTotal() {
        return getDuracionBase() + minutosPreguntas;
    }

    @Override
    public void presentar() {
        System.out.println("Presentacion de charla: " + getTitulo() + ".");

    }

    @Override
    public String toString() {
        return "Charla [codigo= " + getCodigo() + ", titulo= " + getTitulo()
                + ", franja= " + getFranja() + ", duracionBase= " + getDuracionBase()
                + ", minutosPreguntas= " + minutosPreguntas;

    }

    @Override
    public String reservarLugar() {
        if (cupos == 0) {
            throw new IllegalStateException("No quedan lugares disponibles en " + getTitulo() + ".");
        }
        cupos--;
        return "Reserva confirmada para " + getTitulo() + ". Cupos restantes: " + cupos + ".";
    }

}
