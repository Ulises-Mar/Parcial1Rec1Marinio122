package festivaldeciencia;

/**
 * Contrato para realizar una presentacion
 */
public interface Presentable {

    /**
     * realiza una presentacion ante el publico.
     */
    void presentar();
}
