package festivaldeciencia;

import java.util.List;

public class GestionFestivalCiencia {

    public static void main(String[] args) {

        Festival festival = new Festival("Ciencia Abierta");

        agregar(festival, new Charla("C01", "IA Creativa",
                FranjaHoraria.MATUTINA, 40, 10, 2));

        agregar(festival, new Taller("T02", "Robotica",
                FranjaHoraria.VESPERTINA, 60, 30, 1));

        agregar(festival, new MuestraInteractiva("M03", "Ciencia Viva",
                FranjaHoraria.MATUTINA, 25, 4));

        agregar(festival, new Charla("C04", "Astronomia",
                FranjaHoraria.NOCTURNA, 35, 15, 1));

        agregar(festival, new Taller("C01", "IA Creativa",
                FranjaHoraria.NOCTURNA, 20, 5, 3));

        System.out.println("---------------------------------------");
        System.out.println("ACTIVIDADES");
        mostrarActividades(festival.obtenerActividades());
        System.out.println("---------------------------------------");
        System.out.println("DURACIONES");
        mostrarDuraciones(festival.obtenerActividades());
        System.out.println("---------------------------------------");
        System.out.println("PRESENTACIONES");
        realizarPresentaciones(festival.obtenerActividades());
        System.out.println("---------------------------------------");
        System.out.println("RESERVAS");
        reservarActividades(festival.obtenerActividades());
        System.out.println("---------------------------------------");
        System.out.println("MATUTINA");
        mostrarActividades(festival.filtrarPorFranja(FranjaHoraria.MATUTINA));
        System.out.println("---------------------------------------");
        System.out.println("HASTA 50 MINUTOS");
        mostrarActividades(festival.obtenerActividadesDeDuracionMaxima(50));
    }

    /**
     * implemento este metodo agregar para trycatchear los agregados al
     * festival.
     *
     * @param festival festival al que se le agrega.
     * @param actividad actividad a agregar.
     */
    private static void agregar(Festival festival, Actividad actividad) {
        try {
            festival.agregarActividad(actividad);
        } catch (ActividadDuplicadaException e) {
            System.out.println("Duplicado: " + e.getMessage());
        }
    }

    /**
     * muestra las actividades.
     *
     * @param actividades actividades a mostrar.
     */
    private static void mostrarActividades(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            System.out.println(a);
        }
    }

    /**
     * muestra las duraciones.
     *
     * @param actividades actividades con sus duraciones.
     */
    private static void mostrarDuraciones(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            System.out.println(a.getTitulo() + ": " + a.calcularDuracionTotal() + " minutos.");
        }
    }

    /**
     * realiza presentaciones de las actividades que cumplan el contrato.
     *
     * @param actividades actividades a realizar presentacion, si no indica que
     * no la realiza.
     */
    private static void realizarPresentaciones(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            if (a instanceof Presentable) {
                ((Presentable) a).presentar();
            } else {
                System.out.println(a.getTitulo() + " no realiza presentacion.");
            }
        }
    }

    /**
     * realiza reservaciones de las actividades que cumplan el contrato.
     *
     * @param actividades actividades a reservar, si no indica que no admite
     * reservas.
     */
    private static void reservarActividades(List<Actividad> actividades) {
        for (Actividad a : actividades) {
            if (a instanceof Reservable) {
                System.out.println(((Reservable) a).reservarLugar());
            } else {
                System.out.println(a.getTitulo() + " no admitre reservas.");
            }
        }
    }

}
