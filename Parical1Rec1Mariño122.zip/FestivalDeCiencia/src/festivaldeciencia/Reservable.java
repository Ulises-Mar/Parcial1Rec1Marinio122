package festivaldeciencia;

/**
 * Actividad que admite reservas de lugares.
 */
public interface Reservable {

    /**
     * reserva un lugar.
     *
     * @return mensaje de confirmacion.
     * @throws IllegalStateException si no quedan lugares.
     */
    String reservarLugar();

}
