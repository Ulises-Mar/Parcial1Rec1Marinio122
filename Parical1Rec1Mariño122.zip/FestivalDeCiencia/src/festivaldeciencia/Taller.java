package festivaldeciencia;

/**
 * Taller del festival. Admite Reservas pero no presenta.
 */
public class Taller extends Actividad implements Reservable {

    private final int minutosPractica;
    private int cupos;

    public Taller(String codigo, String titulo, FranjaHoraria franja, int duracionBase, int minutosPractica, int cupos) {
        super(codigo, titulo, franja, duracionBase);
        validarMayorCero(minutosPractica);
        validarMayorCero(cupos);
        this.minutosPractica = minutosPractica;
        this.cupos = cupos;
    }

    public int getMinutosPractica() {
        return minutosPractica;
    }

    @Override
    public int calcularDuracionTotal() {
        return getDuracionBase() + minutosPractica;
    }

    @Override
    public String toString() {
        return "Taller [codigo= " + getCodigo() + ", titulo= " + getTitulo()
                + ", franja= " + getFranja() + ", duracionBase= " + getDuracionBase()
                + ", minutosPractica= " + minutosPractica;
    }

    @Override
    public String reservarLugar() {
        if (cupos == 0) {
            throw new IllegalStateException("No quedan lugares disponibles en " + getTitulo() + ".");
        }
        cupos--;
        return "Reserva confirmada para " + getTitulo() + ". Cupos restantes: " + cupos + ".";
    }

}
